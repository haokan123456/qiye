<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:68:"D:\www\tp_proj\qiye\public/../application/test\view\index\index.html";i:1578914046;}*/ ?>
