<?php
namespace app\test\controller;

class UserType
{

}