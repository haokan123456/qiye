<?php
namespace app\test\model;

use think\Model;

class UserType extends Model
{

}