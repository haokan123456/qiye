<?php
namespace app\test\model;
use think\Model;

class Cate extends Model
{
	public function add($ct)
	{
	}
}