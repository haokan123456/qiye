<?php
namespace app\test\model;

use think\Model;

class User extends Model
{

}